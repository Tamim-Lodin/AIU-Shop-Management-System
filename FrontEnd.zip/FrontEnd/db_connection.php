<?php
$servername = 'localhost';
$username = 'root';
$password = 'SQL_123_my';
$database = 'aiu_shop';

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
