<?php
include 'db_connect.php';

// Insert Operation
if (isset($_POST['insert'])) {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $position = $_POST['position'];
    $email = $_POST['email'];
    $phoneNumber = $_POST['phone_number'];

    $stmt = $conn->prepare("INSERT INTO employee_information (first_name, last_name, position, email, phone_number) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $firstName, $lastName, $position, $email, $phoneNumber);
    
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$conn->close();
header("Location: employee_information.php"); // Redirect back to the employee_information page
exit();
?>
