import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="SQL_123_my",
  database="lab_class"
)

mycursor = mydb.cursor()  # Create the cursor object

sql = "INSERT INTO customer (cus_code, cus_name, cus_fname, cus_initial, cus_areacode, cus_phone, cus_balance) VALUES (%s, %s, %s, %s, %s, %s, %s)"
val = (12333, "ali", "ahamad", "e", "15", "51212", 50.00)  
mycursor.execute(sql, val)
mydb.commit()

print(mycursor.rowcount, "record inserted.")  
mycursor.close()
mydb.close()
"""
for udating
try:
    sql = "UPDATE customer SET cus_balance = 600.00 WHERE cus_code = 1234"  # Replace with desired updates and condition
    mycursor.execute(sql)
    mydb.commit()
    print(mycursor.rowcount, "record(s) affected.")
except mysql.connector.Error as err:
    print("Error updating record:", err)
finally:
    mycursor.close()
    mydb.close()
"""
