import mysql.connector
from mysql.connector import Error

def get_db_connection():
    """Create and return a database connection."""
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='SQL_123_my',
            database='aiu_shop'
        )
        return connection
    except Error as err:
        print(f"Error: {err}")
        return None

def fetch_records(table_name):
    """Fetch and return all records from the specified table."""
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor(dictionary=True)
            query = f"SELECT * FROM {table_name}"
            cursor.execute(query)
            records = cursor.fetchall()
            return records
        except Error as err:
            print(f"Error: {err}")
            return []
        finally:
            cursor.close()
            connection.close()
    else:
        return []

def execute_query(query, params=None):
    """Execute a query and return the result."""
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            cursor.execute(query, params)
            connection.commit()
            return "Query executed successfully."
        except Error as err:
            print(f"Error: {err}")
            return f"Error: {err}"
        finally:
            cursor.close()
            connection.close()
    else:
        return "Failed to connect to the database."

def get_columns(table_name):
    """Get and return column information for the specified table."""
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor(dictionary=True)
            query = f"SHOW COLUMNS FROM {table_name}"
            cursor.execute(query)
            columns = cursor.fetchall()
            return columns
        except Error as err:
            print(f"Error: {err}")
            return []
        finally:
            cursor.close()
            connection.close()
    else:
        return []

def insert_record(table_name, values):
    """Insert a record into the specified table and return the result."""
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            columns = ', '.join(values.keys())
            placeholders = ', '.join(['%s'] * len(values))
            query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            cursor.execute(query, list(values.values()))
            connection.commit()
            return "Record inserted successfully."
        except Error as err:
            print(f"Error: {err}")
            return f"Error: {err}"
        finally:
            cursor.close()
            connection.close()
    else:
        return "Failed to connect to the database."

def update_record(table_name, record_id, values):
    """Update a record in the specified table and return the result."""
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            set_clause = ', '.join([f"{column} = %s" for column in values.keys()])
            query = f"UPDATE {table_name} SET {set_clause} WHERE {table_name}_id = %s"
            cursor.execute(query, list(values.values()) + [record_id])
            connection.commit()
            return "Record updated successfully."
        except Error as err:
            print(f"Error: {err}")
            return f"Error: {err}"
        finally:
            cursor.close()
            connection.close()
    else:
        return "Failed to connect to the database."

def delete_record(table_name, record_id):
    """Delete a record from the specified table and return the result."""
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            query = f"DELETE FROM {table_name} WHERE {table_name}_id = %s"
            cursor.execute(query, (record_id,))
            connection.commit()
            return "Record deleted successfully."
        except Error as err:
            print(f"Error: {err}")
            return f"Error: {err}"
        finally:
            cursor.close()
            connection.close()
    else:
        return "Failed to connect to the database."
