from flask import Flask, request, jsonify
from theconnection import get_db_connection, insert_record, update_record, delete_record

app = Flask(__name__)

@app.route('/')
def index():
    return "Welcome to the Database Web App"

@app.route('/insert/<table_name>', methods=['POST'])
def insert(table_name):
    data = request.json
    result = insert_record(table_name, data)
    return jsonify(result)

@app.route('/update/<table_name>/<record_id>', methods=['POST'])
def update(table_name, record_id):
    data = request.json
    result = update_record(table_name, record_id, data)
    return jsonify(result)

@app.route('/delete/<table_name>/<record_id>', methods=['POST'])
def delete(table_name, record_id):
    result = delete_record(table_name, record_id)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
