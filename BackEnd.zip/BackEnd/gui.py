import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from theconnection import fetch_records, execute_query, get_columns, insert_record, update_record, delete_record

class DatabaseGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Database GUI")
        self.initialize_ui()

    def initialize_ui(self):
        # Initialize login window
        self.login_window()

    def login_window(self):
        self.login_win = tk.Toplevel(self.root)
        self.login_win.title("Login")
        self.login_win.geometry("300x200")  # Set window size

        # Center the window on the screen
        window_width = 300
        window_height = 200
        screen_width = self.login_win.winfo_screenwidth()
        screen_height = self.login_win.winfo_screenheight()
        center_x = int(screen_width / 2 - window_width / 2)
        center_y = int(screen_height / 2 - window_height / 2)
        self.login_win.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')

        # Set the login window background color
        self.login_win.configure(bg='#e1e1e1')  # A neutral grey color

        # Username Label and Entry
        tk.Label(self.login_win, text="Username:", bg='#e1e1e1').place(x=50, y=50)
        self.username_entry = tk.Entry(self.login_win, width=20)
        self.username_entry.place(x=130, y=50)

        # Password Label and Entry
        tk.Label(self.login_win, text="Password:", bg='#e1e1e1').place(x=50, y=90)
        self.password_entry = tk.Entry(self.login_win, width=20, show="*")
        self.password_entry.place(x=130, y=90)

        # Login Button
        login_btn = tk.Button(self.login_win, text="Login", command=self.check_login, bg='#4caf50', fg='white')
        login_btn.place(x=130, y=130)

    def check_login(self):
        # Hardcoded credentials for now
        correct_username = "tamim"
        correct_password = "123"
        username = self.username_entry.get()
        password = self.password_entry.get()

        if username == correct_username and password == correct_password:
            messagebox.showinfo("Login Successful", "Welcome, Tamim!")
            self.login_win.destroy()
            self.initialize_main_ui()  # Initialize the main UI after successful login
        else:
            messagebox.showerror("Login Failed", "Incorrect username or password.")

    def initialize_main_ui(self):
        self.tab_control = ttk.Notebook(self.root)

        # Styling
        style = ttk.Style(self.root)
        style.configure('TButton', background='lightblue', font=('Helvetica', 10))

        # Create a tab for each table
        self.tabs = {}
        self.tree_views = {}
        table_names = ["employee_information", "access_right", "customer_information", "feedback", "supplier_information", "product_catelog", "price_details", "product_information", "purchase_history", "sales_transaction", "stock_levels", "task_assignment"]
        for table_name in table_names:
            tab = ttk.Frame(self.tab_control)
            self.tabs[table_name] = tab
            self.tab_control.add(tab, text=table_name)

            # TreeView for each table
            columns = get_columns(table_name)
            column_names = [column['Field'] for column in columns]
            tree_view = ttk.Treeview(tab, columns=column_names, show='headings')
            for col in column_names:
                tree_view.heading(col, text=col)
            tree_view.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

            # Scrollbar for the Treeview
            scrollbar = ttk.Scrollbar(tab, orient=tk.VERTICAL, command=tree_view.yview)
            tree_view.configure(yscroll=scrollbar.set)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

            self.tree_views[table_name] = tree_view

            # Fetch and display records
            self.fetch_records(table_name)

            # Insert, Update, Delete Buttons for each table
            button_frame = ttk.Frame(tab)
            button_frame.pack(side=tk.BOTTOM, fill=tk.X)
            ttk.Button(button_frame, text="Insert Record", command=lambda tn=table_name: self.insert_record(tn)).pack(side=tk.LEFT, padx=5, pady=5)
            ttk.Button(button_frame, text="Update Record", command=lambda tn=table_name: self.update_record(tn)).pack(side=tk.LEFT, padx=5, pady=5)
            ttk.Button(button_frame, text="Delete Record", command=lambda tn=table_name, tv=tree_view: self.delete_record(tn, tv)).pack(side=tk.LEFT, padx=5, pady=5)

        self.tab_control.pack(expand=1, fill="both")

    def fetch_records(self, table_name):
        records = fetch_records(table_name)
        tree_view = self.tree_views[table_name]
        tree_view.delete(*tree_view.get_children())
        for row in records:
            tree_view.insert('', tk.END, values=list(row.values()))

    def insert_record(self, table_name):
        columns = get_columns(table_name)
        if not columns:
            messagebox.showerror("Error", "Failed to retrieve column names.")
            return
        column_names = [column['Field'] for column in columns]

        top = tk.Toplevel(self.root)
        top.title(f"Insert Record into {table_name}")

        entry_widgets = {}
        for column_name in column_names:
            label = tk.Label(top, text=column_name.capitalize())
            label.grid(row=column_names.index(column_name), column=0, padx=10, pady=5, sticky=tk.E)

            entry = tk.Entry(top, width=30)
            entry.grid(row=column_names.index(column_name), column=1, padx=10, pady=5, sticky=tk.W)

            entry_widgets[column_name] = entry

        def submit():
            try:
                values = {cn: entry_widgets[cn].get() for cn in column_names}
                result = insert_record(table_name, values)
                self.display_result(result)
                self.fetch_records(table_name)  # Refresh records after insertion
            except Exception as e:
                messagebox.showerror("Error", str(e))
            finally:
                top.destroy()

        submit_button = tk.Button(top, text="Submit", command=submit)
        submit_button.grid(row=len(column_names), column=0, columnspan=2, pady=10)

        # Additional button to close the window
        close_button = tk.Button(top, text="Close", command=top.destroy)
        close_button.grid(row=len(column_names) + 1, column=0, columnspan=2, pady=5)

    def update_record(self, table_name):
        messagebox.showinfo("Update Record", "Update functionality will be implemented here.")
        # Implementation needed: Fetch the record to be updated and provide an interface to update the fields.

    def delete_record(self, table_name, tree_view):
        selected_item = tree_view.selection()
        if not selected_item:
            messagebox.showerror("Error", "No record selected.")
            return
        try:
            record_id_column_name = f"{table_name}_id"  # Adjust if your primary key column name is different
            record_id = tree_view.item(selected_item)['values'][0]  # Adjust the index if the ID is not the first column
            result = delete_record(table_name, record_id_column_name, record_id)  # Pass column name to the function
            if result == "Record deleted successfully.":
                tree_view.delete(selected_item)
                self.display_result(result)
            else:
                messagebox.showerror("Error", result)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def display_result(self, result):
        # This method should be implemented to display the result of database operations
        pass

if __name__ == "__main__":
    root = tk.Tk()
    app = DatabaseGUI(root)
    root.mainloop()




















"""
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from theconnection import fetch_records, execute_query, get_columns, insert_record, update_record, delete_record

class DatabaseGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Database GUI")
        self.initialize_ui()

    def initialize_ui(self):
        # Initialize login window
        self.login_window()

    def login_window(self):
        self.login_win = tk.Toplevel(self.root)
        self.login_win.title("Login")

        # Set the position of the window to the center of the screen
        window_width = 300
        window_height = 200
        screen_width = self.login_win.winfo_screenwidth()
        screen_height = self.login_win.winfo_screenheight()
        center_x = int(screen_width / 2 - window_width / 2)
        center_y = int(screen_height / 2 - window_height / 2)
        self.login_win.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')

        # Set the login window background color
        self.login_win.configure(bg='#a52a2a')  # A shade of brown

        # Username
        tk.Label(self.login_win, text="Username:", bg='#a52a2a').place(x=50, y=50)
        self.username_entry = tk.Entry(self.login_win, width=20)
        self.username_entry.place(x=130, y=50)

        # Password
        tk.Label(self.login_win, text="Password:", bg='#a52a2a').place(x=50, y=90)
        self.password_entry = tk.Entry(self.login_win, width=20, show="*")
        self.password_entry.place(x=130, y=90)

        # Login Button
        login_btn = tk.Button(self.login_win, text="Login", command=self.check_login)
        login_btn.place(x=130, y=130)

    def check_login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # For now, just check if username and password are not empty
        if username and password:
            messagebox.showinfo("Login Successful", "Welcome!")
            self.login_win.destroy()
            self.initialize_main_ui()  # Initialize the main UI after successful login
        else:
            messagebox.showerror("Login Failed", "Please enter both username and password.")

    def initialize_main_ui(self):
        self.tab_control = ttk.Notebook(self.root)

        # Styling
        style = ttk.Style(self.root)
        style.configure('TButton', background='lightblue', font=('Helvetica', 10))

        # Create a tab for each table
        self.tabs = {}
        self.tree_views = {}
        table_names = ["employee_information", "access_right", "customer_information", "feedback", "supplier_information", "product_catelog", "price_details", "product_information", "purchase_history", "sales_transaction", "stock_levels", "task_assignment"]
        for table_name in table_names:
            tab = ttk.Frame(self.tab_control)
            self.tabs[table_name] = tab
            self.tab_control.add(tab, text=table_name)

            # TreeView for each table
            columns = get_columns(table_name)
            column_names = [column['Field'] for column in columns]
            tree_view = ttk.Treeview(tab, columns=column_names, show='headings')
            for col in column_names:
                tree_view.heading(col, text=col)
            tree_view.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

            # Scrollbar for the Treeview
            scrollbar = ttk.Scrollbar(tab, orient=tk.VERTICAL, command=tree_view.yview)
            tree_view.configure(yscroll=scrollbar.set)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

            self.tree_views[table_name] = tree_view

            # Fetch and display records
            self.fetch_records(table_name)

            # Insert, Update, Delete Buttons for each table
            button_frame = ttk.Frame(tab)
            button_frame.pack(side=tk.BOTTOM, fill=tk.X)
            ttk.Button(button_frame, text="Insert Record", command=lambda tn=table_name: self.insert_record(tn)).pack(side=tk.LEFT, padx=5, pady=5)
            ttk.Button(button_frame, text="Update Record", command=lambda tn=table_name: self.update_record(tn)).pack(side=tk.LEFT, padx=5, pady=5)
            ttk.Button(button_frame, text="Delete Record", command=lambda tn=table_name, tv=tree_view: self.delete_record(tn, tv)).pack(side=tk.LEFT, padx=5, pady=5)

        self.tab_control.pack(expand=1, fill="both")

    def fetch_records(self, table_name):
        records = fetch_records(table_name)
        tree_view = self.tree_views[table_name]
        tree_view.delete(*tree_view.get_children())
        for row in records:
            tree_view.insert('', tk.END, values=list(row.values()))

    def insert_record(self, table_name):
        columns = get_columns(table_name)
        if not columns:
            messagebox.showerror("Error", "Failed to retrieve column names.")
            return
        column_names = [column['Field'] for column in columns]

        top = tk.Toplevel(self.root)
        top.title(f"Insert Record into {table_name}")

        entry_widgets = {}
        for column_name in column_names:
            label = tk.Label(top, text=column_name.capitalize())
            label.grid(row=column_names.index(column_name), column=0, padx=10, pady=5, sticky=tk.E)

            entry = tk.Entry(top, width=30)
            entry.grid(row=column_names.index(column_name), column=1, padx=10, pady=5, sticky=tk.W)

            entry_widgets[column_name] = entry

        def submit():
            try:
                values = {cn: entry_widgets[cn].get() for cn in column_names}
                result = insert_record(table_name, values)
                self.display_result(result)
                self.fetch_records(table_name)  # Refresh records after insertion
            except Exception as e:
                messagebox.showerror("Error", str(e))
            finally:
                top.destroy()

        submit_button = tk.Button(top, text="Submit", command=submit)
        submit_button.grid(row=len(column_names), column=0, columnspan=2, pady=10)

        # Additional button to close the window
        close_button = tk.Button(top, text="Close", command=top.destroy)
        close_button.grid(row=len(column_names) + 1, column=0, columnspan=2, pady=5)

    def update_record(self, table_name):
        messagebox.showinfo("Update Record", "Update functionality will be implemented here.")
        # Implementation needed: Fetch the record to be updated and provide an interface to update the fields.

    def delete_record(self, table_name, tree_view):
        selected_item = tree_view.selection()
        if not selected_item:
            messagebox.showerror("Error", "No record selected.")
            return
        try:
            record_id_column_name = f"{table_name}_id"  # Adjust if your primary key column name is different
            record_id = tree_view.item(selected_item)['values'][0]  # Adjust the index if the ID is not the first column
            result = delete_record(table_name, record_id_column_name, record_id)  # Pass column name to the function
            if result == "Record deleted successfully.":
                tree_view.delete(selected_item)
                self.display_result(result)
            else:
                messagebox.showerror("Error", result)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def display_result(self, result):
        # This method should be implemented to display the result of database operations
        pass

if __name__ == "__main__":
    root = tk.Tk()
    app = DatabaseGUI(root)
    root.mainloop()
"""